=== Last modified header ===
Contributors:  pcdr.marty
Donate link: http://www.pcdr.cz
Tags: last modified
Requires at least: 3.0.1
Tested up to: 3.5.1
Stable tag: 3.5.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Automatically send HTTP Header "last-modified".

== Description ==

Automatically send HTTP Header "last-modified".
You can use post last modification time or creation date... (settings in administration)

== Installation ==

Upload `last_modified_header.php` to the `/wp-content/plugins/` directory and 
activate the plugin through the 'Plugins' menu in WordPress
That's all :)

== Changelog ==

= 1.0 =
* First public release ( 11.2.2013 )
